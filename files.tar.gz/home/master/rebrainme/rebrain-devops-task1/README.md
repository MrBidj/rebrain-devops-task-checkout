full config nxinx from lxc/nginx v.1.0 2020-02-04
